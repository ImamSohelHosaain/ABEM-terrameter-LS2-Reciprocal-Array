#v1.0 Reciprocal script to create individual reciprocal measurements for each Tx-Rx pair /HHI
#Original v2 edited original calculator to print out finished xml files in format that you give /RKA
#v2.1 import original xml instead of editing text file
#v2.2 Code generalised to handle more .XML measurement formats /HHI

import re

def calculate_single_measurement(measurement_str):
    """
    Calculate individual reciprocal measurements for each Tx-Rx pair in a measurement block.
    Now creates separate reciprocal measurements for each original Tx-Rx combination.
    """
    # Extract Tx value
    tx_match = re.search(r"<Tx>\s*(.*?)\s*</Tx>", measurement_str, re.DOTALL)
    
    # Extract all Rx values
    rx_matches = re.findall(r"<Rx>\s*(.*?)\s*</Rx>", measurement_str, re.DOTALL)
    
    if tx_match and rx_matches:
        tx_value = tx_match.group(1).strip()
        
        # Collect all Rx values
        rx_values = []
        for rx_match in rx_matches:
            # Handle multi-line Rx values by extracting each pair of numbers
            rx_pairs = re.findall(r"\d+\s+\d+", rx_match)
            rx_values.extend([pair.strip() for pair in rx_pairs])
        
        if rx_values:
            # Create individual reciprocal measurements for each Tx-Rx pair
            reciprocal_measurements = []
            
            for rx_value in rx_values:
                # Create one reciprocal measurement per original Tx-Rx pair
                reciprocal_measurement = "<Measure>\n"
                reciprocal_measurement += f"    <Tx>{rx_value}</Tx>\n"
                reciprocal_measurement += f"    <Rx>{tx_value}</Rx>\n"
                reciprocal_measurement += "</Measure>\n"
                
                reciprocal_measurements.append(reciprocal_measurement)
            
            return reciprocal_measurements
    
    return []

def calculate_reciprocal(input_file):
    """
    Calculate individual reciprocal measurements for all measurements in the file.
    Creates one reciprocal measurement for each original Tx-Rx pair.
    """
    # Read the entire file content
    with open(input_file, "r") as file:
        xml_content = file.read()
    
    # Extract all <Measure> blocks
    measure_blocks = re.findall(r"<Measure>.*?</Measure>", xml_content, re.DOTALL)
    
    # Calculate reciprocals for each measurement
    all_reciprocals = []
    original_pairs = 0
    
    for measure in measure_blocks:
        reciprocals = calculate_single_measurement(measure)
        all_reciprocals.extend(reciprocals)
        
        # Count original Tx-Rx pairs for verification
        tx_match = re.search(r"<Tx>\s*(.*?)\s*</Tx>", measure, re.DOTALL)
        rx_matches = re.findall(r"<Rx>\s*(.*?)\s*</Rx>", measure, re.DOTALL)
        
        if tx_match and rx_matches:
            for rx_match in rx_matches:
                rx_pairs = re.findall(r"\d+\s+\d+", rx_match)
                original_pairs += len(rx_pairs)
    
    print(f"Original measurements contained {original_pairs} Tx-Rx pairs")
    print(f"Generated {len(all_reciprocals)} individual reciprocal measurements")
    
    return all_reciprocals

def main():
    print("Reciprocal Calculator v3.0 - Individual Reciprocals")
    print("Creates one reciprocal measurement for each original Tx-Rx pair")
    inputfile = input("What is the filename of the original protocol you want to make reciprocal? Make sure it exists in the calculator folder: ")
    
    # Calculate reciprocal measurements
    reciprocal_measurements = calculate_reciprocal(inputfile)
    
    if not reciprocal_measurements:
        print("Warning: No reciprocal measurements were generated. Check the input file format.")
        return
    
    # Get output information
    output_file_path = input("What file name do you want to use? ex. yourprotocol.xml: ")
    spreadname = input("What filename does your spreadfile have? ")
    arraycodenr = input("What arraycode do you want to use? ")
    
    # Write the results to the output file
    with open(output_file_path, "w") as output_file:
        output_file.write('<?xml version="1.0" encoding="UTF-8" ?>\n')
        output_file.write('<Protocol>\n')
        output_file.write('<Name>Reciprocal_')
        output_file.write(output_file_path.replace('.xml', ''))
        output_file.write('</Name>\n')
        output_file.write('<Description>Individual reciprocal measurements generated from ')
        output_file.write(inputfile)
        output_file.write(' - One reciprocal per Tx-Rx pair</Description>\n')
        output_file.write('<SpreadFile>')
        output_file.write(spreadname)
        output_file.write('</SpreadFile>\n')
        output_file.write('<Arraycode>')
        output_file.write(arraycodenr)
        output_file.write('</Arraycode>\n')
        output_file.write('<Sequence>\n')
        
        for result in reciprocal_measurements:
            output_file.write(result)
        
        output_file.write('</Sequence>\n')
        output_file.write('</Protocol>')
    
    print(f"Individual reciprocal measurements have been saved to {output_file_path}")
    print("Each original Tx-Rx pair now has its own reciprocal measurement.")

if __name__ == "__main__":
    main()